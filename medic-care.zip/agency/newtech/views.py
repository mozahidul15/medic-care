from django.shortcuts import render
from . models import Contact
# Create your views here.



def contact(request):
   
    if request.method=="POST":
        name = request.POST['name']
        email = request.POST['email']
        message = request.POST['message']
        phone = request.POST['phone']
        date = request.POST['date']
        
        print(name)
        print(email)

        obj = Contact(name=name, email=email, message=message, phone=phone, date=date)
        obj.save()
    
    return render(request, 'index.html')
